<?php

return [

    'api_key' => env('MONNIFY_API_KEY'),

    'secret_key' => env('MONNIFY_SECRET_KEY'),

    'base_url' => env('MONNIFY_BASE_URL'),

    'contract_code' => env('CONTRACT_CODE'),

];

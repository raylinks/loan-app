<?php

return [
    
    'frontend_url' => env('APP_WEB_URL', 'http://localhost:8080'),
];

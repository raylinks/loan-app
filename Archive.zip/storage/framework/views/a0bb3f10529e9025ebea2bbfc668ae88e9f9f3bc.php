<table width="100%" cellpadding="0" cellspacing="0"
       style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
    <?php echo e($slot); ?>


    <tr style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
        <td class="content-block"
            style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px; float: right; font-style: italic;"
            valign="top">
            Lazy Nerd.
        </td>
    </tr>
</table>
<?php /**PATH /Users/rilwan/Documents/my-projects/loan-app/resources/views/layouts/emails/components/table.blade.php ENDPATH**/ ?>
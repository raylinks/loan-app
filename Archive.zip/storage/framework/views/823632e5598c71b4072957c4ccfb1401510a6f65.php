<div class="navbar navbar-expand-lg navbar-light">
    <div class="text-center d-lg-none w-100">
        <button type="button" class="navbar-toggler dropdown-toggle" data-toggle="collapse" data-target="#navbar-footer">
            <i class="icon-unfold mr-2"></i>
            Footer
        </button>
    </div>

    <div class="navbar-collapse collapse" id="navbar-footer">
        <span class="navbar-text">
            &copy; <?php echo e(date('Y')); ?> Lifdoc
        </span>
    </div>
</div>
<?php /**PATH /Users/rilwan/Documents/my-projects/loan-app/resources/views/layouts/partials/footer.blade.php ENDPATH**/ ?>
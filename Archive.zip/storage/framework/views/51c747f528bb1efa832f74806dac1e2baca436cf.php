<?php $__env->startComponent('mail::message'); ?>
<p> Hi <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>, </p>
<p> You recently requested to reset the password for your account. Use the
    button below to reset it. <strong>This password reset is only valid for the next 1 hour.</strong></p>
<?php $__env->startComponent('mail::button', ['url' => config('settings.frontend_url') . '/reset-password?' . $urlQuery]); ?>
Reset password
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><p> If you’re having trouble with the
    button
    above, copy and paste the URL below into your web
    browser.</p>
<p><p>
<?php $__env->startComponent('mail::panel'); ?>
<p>For security, If you did not request a password reset, please
    ignore this email or send a mail to <?php echo e(config('mail.from.address')); ?>,
    if you have questions.</p>
<?php if (isset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c)): ?>
<?php $component = $__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c; ?>
<?php unset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?> <?php echo e(config('app.name')); ?> Team.
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/rilwan/Documents/my-projects/loan-app/resources/views/emails/reset.blade.php ENDPATH**/ ?>
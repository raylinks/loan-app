<tr style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; margin: 0;">
    <td class="content-block"
        style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; vertical-align: top; margin: 0; padding: 0 0 20px;"
        valign="top">
        <?php echo e($slot); ?>

    </td>
</tr>
<?php /**PATH /Users/rilwan/Documents/my-projects/loan-app/resources/views/layouts/emails/components/table-row.blade.php ENDPATH**/ ?>
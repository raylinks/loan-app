<?php echo e($slot); ?>

<?php /**PATH /Users/rilwan/Documents/my-projects/loan-app/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
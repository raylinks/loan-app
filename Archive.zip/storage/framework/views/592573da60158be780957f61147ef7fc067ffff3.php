 

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('layouts.emails.components.table'); ?>
        <?php $__env->startComponent('layouts.emails.components.table-row'); ?>
        <p>  Hi <?php echo e($firstname); ?>  </p>
        <?php if (isset($__componentOriginal61b5b40f738582e3ebfba131989b34309b3682b6)): ?>
<?php $component = $__componentOriginal61b5b40f738582e3ebfba131989b34309b3682b6; ?>
<?php unset($__componentOriginal61b5b40f738582e3ebfba131989b34309b3682b6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

        <?php $__env->startComponent('layouts.emails.components.table-row'); ?>
            Please find your OTP PIN below. This OTP is valid for the next 5 minutes.
        <?php if (isset($__componentOriginal61b5b40f738582e3ebfba131989b34309b3682b6)): ?>
<?php $component = $__componentOriginal61b5b40f738582e3ebfba131989b34309b3682b6; ?>
<?php unset($__componentOriginal61b5b40f738582e3ebfba131989b34309b3682b6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

        <?php $__env->startComponent('layouts.emails.components.well'); ?>
            <?php echo e($token); ?>

        <?php if (isset($__componentOriginal444d5f35e78bbc6491bf023ca89f2dec8c4e123c)): ?>
<?php $component = $__componentOriginal444d5f35e78bbc6491bf023ca89f2dec8c4e123c; ?>
<?php unset($__componentOriginal444d5f35e78bbc6491bf023ca89f2dec8c4e123c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php if (isset($__componentOriginal2c47f62df489f26cb5929880a9fd1b8e532e5408)): ?>
<?php $component = $__componentOriginal2c47f62df489f26cb5929880a9fd1b8e532e5408; ?>
<?php unset($__componentOriginal2c47f62df489f26cb5929880a9fd1b8e532e5408); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>  


<?php echo $__env->make('layouts.emails.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rilwan/Documents/my-projects/loan-app/resources/views/emails/register-send-otp.blade.php ENDPATH**/ ?>
<tr style="box-sizing: border-box; font-size: 3rem; display: flex; font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; margin: 10px 0; background-color: #eeeeee; border-radius: 5px; justify-content: center; align-items: center; padding-top: 2.3rem; padding-bottom: 1rem">
    <td class="content-block"
        style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 3rem; vertical-align: top; margin: 0; padding: 0 0 20px; color: rgba(0, 0, 0, 0.7)"
        valign="top">
        <?php echo e($slot); ?>

    </td>
</tr>
<?php /**PATH /Users/rilwan/Documents/my-projects/loan-app/resources/views/layouts/emails/components/well.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $__env->yieldContent('title', 'Home'); ?> - CRED BOLT</title>

    <!-- Global stylesheets -->
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;700&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('global_assets/css/icons/icomoon/styles.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/bootstrap_limitless.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/layout.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/components.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/colors.min.css')); ?>" rel="stylesheet" type="text/css">
    <!-- /global stylesheets -->

    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
    <!-- /Custom Stylesheet -->

    <?php echo $__env->yieldContent('plugin-styles'); ?>
    <?php echo $__env->yieldContent('custom-styles'); ?>
</head>

<body>
     <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    <!-- Page content -->
    <div class="page-content">
        <!-- Sidebar -->
         <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        <!-- /Sidebar -->

        <!-- Main content -->
        <div class="content-wrapper">
            <div class="page-header page-header-light">
                <div class="page-header-content header-elements-md-inline">
                    <div class="page-title d-flex">
                        <h4><?php echo $__env->yieldContent('header'); ?></h4>
                    </div>
                </div>
            </div>

            <!-- Breadcrumbs -->
            <?php echo $__env->yieldContent('breadcrumbs'); ?>
            <!-- /Breadcrumbs -->

            <!-- Page header -->
            <?php echo $__env->yieldContent('page-title'); ?>
            <!-- /page header -->

            <!-- Content area -->
            <div class="content pt-0">
                <!-- Alert component -->
             
                <!-- /Alert component -->

                <!-- Validation errors -->
              
                <!-- /Validation errors -->

                <!-- <?php echo $__env->yieldContent('content'); ?> -->
            </div>
            <!-- /content area -->

            <!-- Footer -->
             <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
            <!-- /footer -->
        </div>
        <!-- /main content -->
    </div>
    <!-- /page content -->

    <script src="<?php echo e(asset('global_assets/js/main/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global_assets/js/main/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global_assets/js/plugins/loaders/blockui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global_assets/js/plugins/tables/datatables/datatables.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>

    <script>
        $.extend( $.fn.dataTable.defaults, {
            autoWidth: false,
            columnDefs: [{
                width: 100,
            }],
            dom: '<"datatable-header"fl><"datatable-scroll"t><"datatable-footer"ip>',
            language: {
                search: '<span>Filter:</span> _INPUT_',
                searchPlaceholder: 'Type to filter...',
                lengthMenu: '<span>Show:</span> _MENU_',
                paginate: { 'first': 'First', 'last': 'Last', 'next': $('html').attr('dir') == 'rtl' ? '&larr;' : '&rarr;', 'previous': $('html').attr('dir') == 'rtl' ? '&rarr;' : '&larr;' }
            },
        });

    </script>

    <?php echo $__env->yieldContent('plugin-scripts'); ?>
    <?php echo $__env->yieldContent('custom-scripts'); ?>
</body>
</html>
<?php /**PATH /Users/rilwan/Documents/my-projects/loan-app/resources/views/layouts/dashboard.blade.php ENDPATH**/ ?>
<center>
    <a href="<?php echo e($link); ?>" class="btn-primary"
       style="font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif; box-sizing: border-box; font-size: 14px; color: #FFF; text-decoration: none; line-height: 2em; font-weight: bold; text-align: center; cursor: pointer; display: inline-block; border-radius: 5px; text-transform: capitalize; background-color: #5fbeaa; margin: 0; border-color: #5fbeaa; border-style: solid; border-width: 10px 20px;">
        <?php echo e($slot); ?>

    </a>
</center>
<?php /**PATH /Users/rilwan/Documents/my-projects/loan-app/resources/views/layouts/emails/components/button.blade.php ENDPATH**/ ?>
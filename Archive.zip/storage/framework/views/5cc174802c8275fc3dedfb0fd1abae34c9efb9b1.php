<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('header', 'Home'); ?>

<?php $__env->startSection('page-title'); ?>
    <div class="page-header">
        <div class="page-header-content header-elements-md-inline">
            <div class="page-title d-flex">
                <h2 class="font-weight-semibold">Dashboard</h2>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-scripts'); ?>
    <script>
        $('#dashboard').addClass('active')
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rilwan/Documents/my-projects/loan-app/resources/views/admin/index.blade.php ENDPATH**/ ?>
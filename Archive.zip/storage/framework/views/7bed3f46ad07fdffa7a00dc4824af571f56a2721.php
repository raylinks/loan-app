<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('layouts.emails.components.table'); ?>
        <?php $__env->startComponent('layouts.emails.components.table-row'); ?>
            Hi <strong><?php echo e($email); ?></strong>,
        <?php if (isset($__componentOriginal61b5b40f738582e3ebfba131989b34309b3682b6)): ?>
<?php $component = $__componentOriginal61b5b40f738582e3ebfba131989b34309b3682b6; ?>
<?php unset($__componentOriginal61b5b40f738582e3ebfba131989b34309b3682b6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

        <?php $__env->startComponent('layouts.emails.components.table-row'); ?>
            Thanks for registering on LAZY NERD. Kindly verify your email address using this
            <a href="<?php echo e($url . '?token=' . $token); ?>">LINK</a> or click on the button below to continue using our site.
        <?php if (isset($__componentOriginal61b5b40f738582e3ebfba131989b34309b3682b6)): ?>
<?php $component = $__componentOriginal61b5b40f738582e3ebfba131989b34309b3682b6; ?>
<?php unset($__componentOriginal61b5b40f738582e3ebfba131989b34309b3682b6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

        <?php $__env->startComponent('layouts.emails.components.table-row'); ?>
            <?php $__env->startComponent('layouts.emails.components.button', ['link' => "$url?token=$token"]); ?>
                Verify Email
            <?php if (isset($__componentOriginala536ff15e399f882e8ac6de41ebcd7a8b72c6ead)): ?>
<?php $component = $__componentOriginala536ff15e399f882e8ac6de41ebcd7a8b72c6ead; ?>
<?php unset($__componentOriginala536ff15e399f882e8ac6de41ebcd7a8b72c6ead); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        <?php if (isset($__componentOriginal61b5b40f738582e3ebfba131989b34309b3682b6)): ?>
<?php $component = $__componentOriginal61b5b40f738582e3ebfba131989b34309b3682b6; ?>
<?php unset($__componentOriginal61b5b40f738582e3ebfba131989b34309b3682b6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php if (isset($__componentOriginal2c47f62df489f26cb5929880a9fd1b8e532e5408)): ?>
<?php $component = $__componentOriginal2c47f62df489f26cb5929880a9fd1b8e532e5408; ?>
<?php unset($__componentOriginal2c47f62df489f26cb5929880a9fd1b8e532e5408); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.emails.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rilwan/Documents/my-projects/loan-app/resources/views/emails/user-registered.blade.php ENDPATH**/ ?>